//CS360 Project 3 - Kari L. Cheslock, 10/11/21
//This code contains the creation of the SQLite database for the inventory items as well as
//all of the CRUD methods for the database.

package com.cs360.inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBHelperInventory extends SQLiteOpenHelper {

    //variables to create database with specified columns
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "inventoryData";

    private static final String TABLE_INVENTORY = "Inventory";

    private static final String KEY_ID = "InventoryId";
    private static final String INVENTORY_ITEM_NAME = "InventoryItemName";
    private static final String PRICE = "Price";
    private static final String QUANTITY = "Quantity";

    //database constructor
    public DBHelperInventory(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase InventoryDB) {
        //creation of inventory table using SQLite with inventory id as integer that will be incremented with each entry
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + INVENTORY_ITEM_NAME + " TEXT,"
                + PRICE + " FLOAT," + QUANTITY + " INTEGER" + ")";
        InventoryDB.execSQL(CREATE_INVENTORY_TABLE);
    }

    //drop table if it already exists
    @Override
    public void onUpgrade(SQLiteDatabase InventoryDB, int i, int i1) {
        InventoryDB.execSQL("drop Table if exists Inventory");
        onCreate(InventoryDB);
    }

    //method to add an inventory item to the database
    void addInventoryItem(InventoryItem inventoryItem) {
        SQLiteDatabase InventoryDB = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_ITEM_NAME, inventoryItem.getInventoryItemName());
        contentValues.put(PRICE, inventoryItem.getPrice());
        contentValues.put(QUANTITY, inventoryItem.getQuantity());

        InventoryDB.insert(TABLE_INVENTORY, null, contentValues);
        InventoryDB.close();
    }


    //method to retrieve and display all inventory items from the database
    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> inventoryList = new ArrayList<InventoryItem>();

        String selectQuery = "SELECT  * FROM " + TABLE_INVENTORY;

        SQLiteDatabase InventoryDB = this.getWritableDatabase();
        Cursor cursor = InventoryDB.rawQuery(selectQuery, null);


        if (cursor.moveToFirst()) {
            do {
                InventoryItem inventoryItem = new InventoryItem();
                inventoryItem.setInventoryId(Integer.parseInt(cursor.getString(0)));
                inventoryItem.setInventoryItemName(cursor.getString(1));
                inventoryItem.setPrice(cursor.getFloat(2));
                inventoryItem.setQuantity(cursor.getInt(3));

                inventoryList.add(inventoryItem);
            } while (cursor.moveToNext());
        }

        return inventoryList;
    }

    //method to edit/update an inventory item
    public int updateInventoryItem(InventoryItem inventoryItem) {
        SQLiteDatabase InventoryDB = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(INVENTORY_ITEM_NAME, inventoryItem.getInventoryItemName());
        contentValues.put(PRICE, inventoryItem.getPrice());
        contentValues.put(QUANTITY, inventoryItem.getQuantity());

        return InventoryDB.update(TABLE_INVENTORY, contentValues, KEY_ID + " = ?",
                new String[] { String.valueOf(inventoryItem.getInventoryId()) });
    }

    //method to delete an item from the inventory
    public void deleteInventoryItem(InventoryItem inventoryItem) {
        SQLiteDatabase InventoryDB = this.getWritableDatabase();
        InventoryDB.delete(TABLE_INVENTORY, KEY_ID + " = ?",
                new String[] { String.valueOf(inventoryItem.getInventoryId()) });
        InventoryDB.close();
    }
}
