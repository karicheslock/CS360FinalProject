//CS360 Project 3 - Kari L. Cheslock, 10/11/21
//This code populates the inventory list in the inventory table for display within the app

package com.cs360.inventoryapp;

import android.app.Activity;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

public class CustomInventoryList extends BaseAdapter {
    //declaring variables
    private Activity context;
    ArrayList<InventoryItem> inventoryItems;
    private PopupWindow pwindo;
    DBHelperInventory db;
    BaseAdapter ba;

    //constructor for the list
    public CustomInventoryList(Activity context, ArrayList<InventoryItem> inventoryItems, DBHelperInventory db) {
        this.context = context;
        this.inventoryItems=inventoryItems;
        this.db=db;
    }

    //TextViews and Buttons to be displayed
    public static class ViewHolder
    {
        TextView textViewInventoryId;
        TextView textViewInventoryItem;
        TextView textViewPrice;
        TextView textViewQuantity;
        Button editButton;
        Button deleteButton;
    }

    //method defining the list of items to be displayed and the OnClickListeners for the edit and delete buttons
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;
        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.row_item, null, true);

            vh.textViewInventoryId = (TextView) row.findViewById(R.id.textViewInventoryId);
            vh.textViewInventoryItem = (TextView) row.findViewById(R.id.textViewInventoryItem);
            vh.textViewPrice = (TextView) row.findViewById(R.id.textViewPrice);
            vh.textViewQuantity = (TextView) row.findViewById(R.id.textViewQuantity);
            vh.editButton = (Button) row.findViewById(R.id.editButton);
            vh.deleteButton = (Button) row.findViewById(R.id.deleteButton);

            row.setTag(vh);
        } else {

            vh = (ViewHolder) convertView.getTag();

        }

        vh.textViewInventoryItem.setText("Item: " + inventoryItems.get(position).getInventoryItemName());
        vh.textViewInventoryId.setText("Inventory Id #: " + inventoryItems.get(position).getInventoryId());
        vh.textViewPrice.setText("Price: $" + inventoryItems.get(position).getPrice());
        vh.textViewQuantity.setText("Quantity Available: " + inventoryItems.get(position).getQuantity());

        final int positionPopup = position;
        vh.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("Save: ", "" + positionPopup);
                editPopup(positionPopup);

            }
        });
        vh.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Last Index", "" + positionPopup);
                //     Integer index = (Integer) view.getTag();
                db.deleteInventoryItem(inventoryItems.get(positionPopup));

                //      countries.remove(index.intValue());
                inventoryItems = (ArrayList) db.getAllInventoryItems();
                Log.d("Inventory Items size", "" + inventoryItems.size());
                notifyDataSetChanged();
            }
        });
        return  row;
    }

    public long getItemId(int position) {
        return position;
    }

    public Object getItem(int position) {
        return position;
    }

    public int getCount() {
        return inventoryItems.size();
    }

    //method defining the popup window after clicking the edit button
    //also sets the OnClickListener for the save button in the popup window
    public void editPopup(final int positionPopup)
    {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_popup,
                (ViewGroup) context.findViewById(R.id.popup_element));
        pwindo = new PopupWindow(layout, 600, 670, true);
        pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);
        final EditText itemNameEdit = (EditText) layout.findViewById(R.id.editTextInventoryItem);
        final EditText priceEdit = (EditText) layout.findViewById(R.id.editTextPrice);
        final EditText quantityEdit = (EditText) layout.findViewById(R.id.editTextQuantity);

        itemNameEdit.setText(inventoryItems.get(positionPopup).getInventoryItemName());
        priceEdit.setText("" + inventoryItems.get(positionPopup).getPrice());
        quantityEdit.setText("" + inventoryItems.get(positionPopup).getQuantity());
        Log.d("Name: ", "" + inventoryItems.get(positionPopup).getPrice());
        Log.d("Name: ", "" + inventoryItems.get(positionPopup).getQuantity());

        Button save = (Button) layout.findViewById(R.id.save_popup);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemNameStr = itemNameEdit.getText().toString();
                String price = priceEdit.getText().toString();
                String quantity = quantityEdit.getText().toString();
                InventoryItem inventoryItem = inventoryItems.get(positionPopup);
                inventoryItem.setInventoryItemName(itemNameStr);

                //check status of SMS toggle switch
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
                String onoff = preferences.getString("value", "");


                //validating user entry
                if(Float.parseFloat(price) < 0 || Integer.parseInt(quantity) < 0) {
                    Toast.makeText(context.getApplicationContext(), "Invalid Entry", Toast.LENGTH_SHORT).show();
                } else if (Integer.parseInt(quantity) == 0 && onoff.equalsIgnoreCase("true")) {
                    inventoryItem.setQuantity(Integer.parseInt(quantity));
                    inventoryItem.setPrice(Float.parseFloat(price));
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("12345", null, itemNameStr + " is out of stock", null, null);
                } else {
                    inventoryItem.setPrice(Float.parseFloat(price));
                    inventoryItem.setQuantity(Integer.parseInt(quantity));
                }


                db.updateInventoryItem(inventoryItem);
                inventoryItems = (ArrayList) db.getAllInventoryItems();
                notifyDataSetChanged();
                for (InventoryItem inventoryItem1 : inventoryItems) {
                    String log = "Id: " + inventoryItem1.getInventoryId() + " ,Name: " + inventoryItem1.getInventoryItemName() +
                            " ,Price: " + inventoryItem1.getPrice() + " ,Quantity: " + inventoryItem1.getQuantity();
                    // Writing Inventory Items to log
                    Log.d("Name: ", log);
                }
                pwindo.dismiss();
            }
        });
    }
}