//CS360 Project 3
//Kari L. Cheslock - 10/11/21
//This project demonstrates a completed application that allows for the management of a small inventory list.


package com.cs360.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //variables for login screen text entries and buttons
    EditText username, password;
    Button submit, register, sms;
    //initializing SQLite user database
    DBHelperLogin DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //defining declared variables
        username = (EditText) findViewById(R.id.editTextPersonName);
        password = (EditText) findViewById((R.id.editTextPassword));
        submit = (Button) findViewById(R.id.buttonSubmit);
        register = (Button) findViewById(R.id.buttonRegister);
        sms = (Button) findViewById(R.id.buttonSmsMain);
        DB = new DBHelperLogin(this);

        //setting OnClickListener for the submit button
        submit.setOnClickListener(new OnClickListener() {
            @Override
          public void onClick(View view) {

                //variables to store info entered by user, converted to String
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //user input validation for login
                if (user.equals("") || pass.equals("")) {
                  Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
              } else {
                  Boolean checkUserPass = DB.checkUsernamePassword(user, pass);
                  if (checkUserPass == true) {
                      Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                      Intent intent = new Intent(getApplicationContext(), InventoryTable.class);
                      startActivity(intent);
                  } else {
                      Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                  }
              }
          }
      });

        //setting OnClickListener for register button
        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                //variables to store info entered by user, converted to string
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //validating user input
                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this,"Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = DB.checkUsername(user);
                    if (checkUser == false) {
                        Boolean insert = DB.insertData(user, pass);
                        if (insert == true) {
                            Toast.makeText(MainActivity.this, "Registered successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), InventoryTable.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this, "Registration failed.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "This user already exists! Please login.", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        //setting OnClickListener for the SMS button
        //tapping this button advances to another screen with a toggle switch
        sms.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SMSToggleSwitch.class);
                startActivity(intent);

            }
        });
    }
}