//CS360 Project 3 - Kari L. Cheslock, 10/11/21
//This code contains the creation of the SQLite database that will hold the usernames and passwords.


package com.cs360.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelperLogin extends SQLiteOpenHelper {

    //database name
    public static final String DBNAME = "Login.db";

    //database constructor
    public DBHelperLogin(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase LoginDB) {
        //creation of SQLite database with username as primary key
        LoginDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase LoginDB, int i, int i1) {
        //drop the SQLite table if it already exists
        LoginDB.execSQL("drop Table if exists users");
    }

    //method to insert new username/password combinations into the table
    public Boolean insertData(String username, String password) {
        SQLiteDatabase LoginDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = LoginDB.insert("users", null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //method to check if username already exists
    public Boolean checkUsername(String username) {
        SQLiteDatabase LoginDB = this.getWritableDatabase();
        Cursor cursor = LoginDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

    //method to validate user credentials
    public Boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase LoginDB = this.getWritableDatabase();
        Cursor cursor = LoginDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if (cursor.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
