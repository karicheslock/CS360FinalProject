//CS360 Project 3 - Kari L. Cheslock, 10/11/21
//This code displays the inventory table for the user within the app

package com.cs360.inventoryapp;

import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.Toast;
import java.util.ArrayList;

public class InventoryTable extends AppCompatActivity {

    //declaring variables
    ArrayList<InventoryItem> inventoryItems;
    DBHelperInventory InventoryDB;
    Button btnAddItem;
    Button smsButton;
    PopupWindow pwindo;
    Activity activity;
    ListView listView;
    CustomInventoryList customInventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_table);
        activity=this;
        InventoryDB= new DBHelperInventory(this);
        listView = (ListView) findViewById(R.id.inventoryList);
        btnAddItem = (Button) findViewById(R.id.buttonAddItem);
        smsButton = (Button) findViewById(R.id.buttonSmsList);

        //OnClickListener for Allow SMS Messaging button
        smsButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SMSToggleSwitch.class);
                startActivity(intent);
            }
        });

        //OnClickListener for Add Item button, displays pop up to add an item to the inventory list
        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addPopUp();
            }
        });
        Log.d("MainActivity: ", "Before reading mainactivity");
        //displaying existing inventory
        inventoryItems = (ArrayList) InventoryDB.getAllInventoryItems();

        for (InventoryItem inventoryItem : inventoryItems) {
            String log = "Id: " + inventoryItem.getInventoryId() + " ,Name: " + inventoryItem.getInventoryItemName() +
                    " ,Price: " + inventoryItem.getPrice() + " ,Quantity: " + inventoryItem.getQuantity();
            // Writing Inventory Items to log
            Log.d("Name: ", log);
        }


        CustomInventoryList customInventoryList = new CustomInventoryList(this, inventoryItems, InventoryDB);
        listView.setAdapter(customInventoryList);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Toast.makeText(getApplicationContext(), "You Selected " + inventoryItems.get(position).getInventoryItemName() + " as Inventory Item", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //popup window to add an item to the inventory
    public void addPopUp() {
        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.edit_popup,
                (ViewGroup) activity.findViewById(R.id.popup_element));
        pwindo = new PopupWindow(layout, 600, 670, true);
        pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);
        final EditText itemNameEdit = (EditText) layout.findViewById(R.id.editTextInventoryItem);
        final EditText priceEdit = (EditText) layout.findViewById(R.id.editTextPrice);
        final EditText quantityEdit = (EditText) layout.findViewById(R.id.editTextQuantity);

        Button save = (Button) layout.findViewById(R.id.save_popup);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemNameStr = itemNameEdit.getText().toString();
                String price = priceEdit.getText().toString();
                String quantity = quantityEdit.getText().toString();

                //validating user entry
                if (Float.parseFloat(price) < 0 || Integer.parseInt(quantity) < 0) {
                    Toast.makeText(getApplicationContext(), "Invalid entry", Toast.LENGTH_SHORT).show();
                } else {
                    InventoryItem inventoryItem = new InventoryItem(itemNameStr, Float.parseFloat(price), Integer.parseInt(quantity));
                    InventoryDB.addInventoryItem(inventoryItem);
                }


                //check status of SMS toggle switch
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                String onoff = preferences.getString("value", "");


                if (Integer.parseInt(quantity) == 0 && onoff.equalsIgnoreCase("true") ) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("12345", null, itemNameStr + " is out of stock", null, null);
                }


                if(customInventoryList==null)
                {
                    customInventoryList = new CustomInventoryList(activity, inventoryItems, InventoryDB);
                    listView.setAdapter(customInventoryList);
                }
                customInventoryList.inventoryItems = (ArrayList) InventoryDB.getAllInventoryItems();
                ((BaseAdapter)listView.getAdapter()).notifyDataSetChanged();
                for (InventoryItem inventoryItem1 : inventoryItems) {
                    String log = "Id: " + inventoryItem1.getInventoryId() + " ,Name: " + inventoryItem1.getInventoryItemName() +
                            " ,Price: " + inventoryItem1.getPrice() + " ,Quantity: " + inventoryItem1.getQuantity();
                    // Writing Inventory Items to log
                    Log.d("Name: ", log);
                }
                pwindo.dismiss();
            }
        });
    }
}