//CS360 Project 3 - Kari L. Cheslock, 10/11/21

//This code defines the InventoryItem class including all associated variables, constructors,
//and getters & setters to define an InventoryItem object.

package com.cs360.inventoryapp;


public class InventoryItem {

    int inventoryId;
    String inventoryItemName;
    float price;
    int quantity;

    public InventoryItem() {
        super();
    }

    public InventoryItem(int inventoryId, String inventoryItemName, float price, int quantity) {
        super();
        this.inventoryId = inventoryId;
        this.inventoryItemName = inventoryItemName;
        this.price = price;
        this.quantity = quantity;
    }

    public InventoryItem(String inventoryItemName, float price, int quantity) {
        this.inventoryItemName = inventoryItemName;
        this.price = price;
        this.quantity = quantity;
    }

    public int getInventoryId() {
        return inventoryId;
    }

    public void setInventoryId(int inventoryId) {
        this.inventoryId = inventoryId;
    }

    public String getInventoryItemName() {
        return inventoryItemName;
    }

    public void setInventoryItemName(String inventoryItemName) {
        this.inventoryItemName = inventoryItemName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
